﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace smart_restaurant
{
    class as
    {
        Public conn; As New OleDbConnection ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\restaurant.accdb;");
             Public da As New OleDbDataAdapter 
            Public dt As New DataTable
    }
}
