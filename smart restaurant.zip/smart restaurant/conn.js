﻿(function () {
    'use strict';

    angular.module('conn', [
        // Angular modules 
        'ngRoute'
         Public conn As New OleDbConnection ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\restaurant.accdb;");
    Public da As New OleDbDataAdapter 
    Public dt As New 
        // Custom modules 

        // 3rd Party Modules
        
    ]);
})();